#FAÇA UM PROGRAMA PARA IDENTIFICAR SE A PESSOA TEM FEBRE OU NÃO E MOSTRAR QUANTO DE FEBRE ELE TEM NA TELA.

febre = int(input('Informe a temperatura do paciente (em graus Celsius): '))


if febre < 30 or febre > 60:
  print('\nVocê digitou a temperatura errado, redigite!')

elif febre < 37:
  print("\nVoce esta sem febre!")
  print("Sua temperatura é de",febre,"graus")

elif febre >= 37:
  print("\nVoce esta com febre! Febre de" ,febre, "graus")