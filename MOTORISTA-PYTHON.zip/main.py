#2 Faça um programa que ajude motoristas calcular e estimar viagens com diferentes tempos de viagem. O programa deve receber do usuário do sistema (motorista) a distância a ser percorrida e o tempo   desejado da viagem. A partir disso, o programa deve calcular e exibir na tela a velocidade média   necessária.

distancia = float(input('Digite a distância da viagem (em km): '))
tempo = float(input('Digite o tempo que a viagem durou (em horas.minutos): '))

media = distancia/tempo

print("\nA velocidade média que você terá que andar para chegar neste tempo será de", round (media,2) , 'km/h.')