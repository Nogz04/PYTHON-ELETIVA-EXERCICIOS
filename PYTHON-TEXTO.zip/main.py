#PEGAR UM TEXTO E IDENTIFICAR QUANTAS PALAVRAS TEM.

def contar_palavras(texto):
    palavras = texto.split()
    return len(palavras)

texto = input("Digite o texto: ")
numero_palavras = contar_palavras(texto)
print(f"O texto possui {numero_palavras} palavras.")
